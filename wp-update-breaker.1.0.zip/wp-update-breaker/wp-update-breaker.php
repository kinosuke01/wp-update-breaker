<?php
/*
Plugin Name: WP Update Breaker
Description: This plugin breaks the site display when updating. Used for testing.
Version: 1.0
Author: kinosuke01
*/
