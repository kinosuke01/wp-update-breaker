<?php
/*
Plugin Name: WP Update Breaker
Description: This plugin breaks the site display when updating. Used for testing.
Version: 1.0
Author: kinosuke01
Plugin URI: https://kinosuke01.github.io/wp-update-breaker/
Update URI: https://kinosuke01.github.io/wp-update-breaker/info.json
*/

require_once 'updater.php';
